from flask import Flask, render_template, request, redirect, send_file, session
import sqlite3
import os
from fpdf import FPDF

app = Flask(__name__)
app.secret_key = 'HEM_SECRET_KEY_2026'

base_dir = os.path.abspath(os.path.dirname(__file__))
db_path = os.path.join(base_dir, 'contacts.db')



def init_db():
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS contacts 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, email TEXT)''')
    conn.commit()
    conn.close()



@app.route('/')
def index():
    search_query = request.args.get('search', '')
    is_admin = session.get('is_admin', False)
    
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM contacts")
    total_contacts = c.fetchone()[0]
    
    if search_query:
        query = "SELECT * FROM contacts WHERE name LIKE ? OR phone LIKE ?"
        c.execute(query, ('%' + search_query + '%', '%' + search_query + '%'))
    else:
        c.execute("SELECT * FROM contacts")
        
    all_contacts = c.fetchall()
    conn.close()
    
    return render_template('index.html', contacts=all_contacts, 
                           search_query=search_query, total=total_contacts, is_admin=is_admin)


@app.route('/admin-login', methods=['POST'])
def admin_login():
    password = request.form.get('password')
    if password == "1234":
        session['is_admin'] = True
    return redirect('/')
@app.route('/admin-logout')
def admin_logout():
    session.pop('is_admin', None)
    return redirect('/')



@app.route('/export')
def export():
    try:
        conn = sqlite3.connect(db_path)
        c = conn.cursor()
        c.execute("SELECT name, phone, email FROM contacts")
        rows = c.fetchall()
        conn.close()

        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", 'B', 16)
        pdf.cell(200, 10, txt="HEM CONTACTS REPORT", ln=True, align='C')
        pdf.ln(10)
        
        pdf.set_font("Arial", 'B', 12)
        pdf.cell(60, 10, "Name", 1)
        pdf.cell(60, 10, "Phone", 1)
        pdf.cell(70, 10, "Email", 1)
        pdf.ln()
        
        pdf.set_font("Arial", size=12)
        for row in rows:
            name = str(row[0]).encode('ascii', 'ignore').decode('ascii') if row[0] else "N/A"
            phone = str(row[1]).encode('ascii', 'ignore').decode('ascii') if row[1] else "N/A"
            email = str(row[2]).encode('ascii', 'ignore').decode('ascii') if row[2] else "N/A"
            
            pdf.cell(60, 10, name, 1)
            pdf.cell(60, 10, phone, 1)
            pdf.cell(70, 10, email, 1)
            pdf.ln()

        pdf_path = os.path.join(base_dir, "contacts_report.pdf")
        pdf.output(pdf_path)
        return send_file(pdf_path, as_attachment=True)
    except Exception as e:
        return f"Error creating PDF: {str(e)}"
    


@app.route('/add', methods=['POST'])
def add():
    name = request.form.get('name')
    phone = request.form.get('phone')
    email = request.form.get('email')
    
    if name and phone:
        conn = sqlite3.connect(db_path)
        c = conn.cursor()
        c.execute("INSERT INTO contacts (name, phone, email) VALUES (?, ?, ?)", (name, phone, email))
        conn.commit()
        conn.close()
    return redirect('/')



@app.route('/delete/<int:id>')
def delete(id):
    if session.get('is_admin'):
        conn = sqlite3.connect(db_path)
        c = conn.cursor()
        c.execute("DELETE FROM contacts WHERE id=?", (id,))
        conn.commit()
        conn.close()
    return redirect('/')

if __name__ == '__main__':
    init_db()
    app.run(debug=True)